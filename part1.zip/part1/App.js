import React, { useEffect, useState } from 'react';
import { FlatList, Text, View, Button } from 'react-native';

const App = () => {
  const [data, setData] = useState([]);

  // Fetch dữ liệu từ MockAPI khi component được mount
  useEffect(() => {
    fetchData();
  }, []);

  // Hàm lấy dữ liệu từ MockAPI
   const fetchData = async () => {
    try {
      let response = await fetch('https://670b41e4ac6860a6c2cb92c9.mockapi.io/users'); 
      let json = await response.json();
      setData(json); // Cập nhật state với dữ liệu mới
    } catch (error) {
      console.error(error);
    }
   };

  // Hàm thêm mới một item
  const addItem = async () => {
    try {
      let response = await fetch('https://670b41e4ac6860a6c2cb92c9.mockapi.io/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: 'New User', // Dữ liệu của item mới
        }),
      });
      await fetchData(); // Cập nhật lại danh sách
    } catch (error) {
      console.error(error);
    }
  };

  // Hàm chỉnh sửa một item theo ID
  const editItem = async (id) => {
    try {
      let response = await fetch(`https://670b41e4ac6860a6c2cb92c9.mockapi.io/users/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: 'Updated User Name', // Dữ liệu mới
        }),
      });
      await fetchData(); // Cập nhật lại danh sách sau khi sửa
    } catch (error) {
      console.error(error);
    }
  };

  // Hàm xóa một item theo ID
  const deleteItem = async (id) => {
    try {
      let response = await fetch(`https://670b41e4ac6860a6c2cb92c9.mockapi.io/users/${id}`, {
        method: 'DELETE',
      });
      await fetchData(); // Cập nhật lại danh sách sau khi xóa
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <View>
      {/* Hiển thị danh sách dữ liệu từ MockAPI */}
      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View>
            <Text>{item.name}</Text>
            <View>
              {/* Nút để chỉnh sửa item */}
              <Button title="Edit" onPress={() => editItem(item.id)} />
              {/* Nút để xóa item */}
              <Button title="Delete" onPress={() => deleteItem(item.id)} />
            </View>
          </View>
        )}
      />
      {/* Nút để thêm mới item */}
      <Button title="Add" onPress={() => addItem()} />
    </View>
  );
};

export default App;